#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/time.h>
#include "fs/operations.h"
#include <unistd.h>

#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100

int numberThreads;
int numberCommands = 0;
int headQueue = 0;
syncS synchstrategy;

char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];

FILE *outputFile, *inputFile;

pthread_mutex_t lock;
pthread_rwlock_t rwlock;


void lock_init()
{
    if (synchstrategy == MUTEX)
	{
        if(pthread_mutex_init(&lock, NULL) != 0)
		{
            fprintf(stderr,"Mutex lock couldn't be initiated.\n");
            exit(EXIT_FAILURE);
        }
    }
    else if(synchstrategy == RWLOCK)
	{
        if(pthread_rwlock_init(&rwlock, NULL) != 0)
		{
            fprintf(stderr,"RW lock couldn't be initiated.\n");
            exit(EXIT_FAILURE);
        }
    }
    else
	{
        if(numberThreads != 1)
		{
            fprintf(stderr,"No Sync type for more than one thread.\n");
            exit(EXIT_FAILURE);
        }
    }
}

void *read_lock_func()
{
    if(synchstrategy == MUTEX)
	{
        if(pthread_mutex_lock(&lock) != 0)
		{
            fprintf(stderr,"Error with mutex_lock.\n");
            exit(EXIT_FAILURE);
        }
    }
    else if(synchstrategy == RWLOCK)
	{
        if(pthread_rwlock_rdlock(&rwlock) != 0)
		{
            fprintf(stderr,"Error with read rwlock.\n");
            exit(EXIT_FAILURE);
        }
    }
    return NULL;
}

void *write_lock_func()
{
    if(synchstrategy == MUTEX)
	{
        if(pthread_mutex_lock(&lock) != 0)
		{
            fprintf(stderr,"Error with mutex_lock.\n");
            exit(EXIT_FAILURE);
        }
    }
    else if(synchstrategy == RWLOCK)
	{
        if(pthread_rwlock_wrlock(&rwlock) != 0)
		{
            fprintf(stderr,"Error with write rwlock.\n");
            exit(EXIT_FAILURE);
        }
    }
    return NULL;
}

void unlock_func()
{
    if(synchstrategy == MUTEX)
	{
        if(pthread_mutex_unlock(&lock) != 0)
		{
            fprintf(stderr,"Error with mutex_unlock.\n");
            exit(EXIT_FAILURE);
        }
    }
    else if(synchstrategy == RWLOCK)
	{
        if (pthread_rwlock_unlock(&rwlock) != 0)
		{
            fprintf(stderr,"Error with rwlock unlock.\n");
            exit(EXIT_FAILURE);
        }
    }
}

int insertCommand(char* data)
{
    if(numberCommands != MAX_COMMANDS)
    {
        strcpy(inputCommands[numberCommands++], data);
        return 1;
    }
    return 0;
}

char* removeCommand()
{
    if(numberCommands > 0)
    {   
        numberCommands--;
        return inputCommands[headQueue++];  
    }
    return NULL;
}

void errorParse()
{
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void processInput(FILE *fp)
{
    char line[MAX_INPUT_SIZE];

    /* break loop with ^Z or ^D */
    while (fgets(line, sizeof(line)/sizeof(char), fp))
    {
        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %c", &token, name, &type);

        /* perform minimal validation */
        if (numTokens < 1)
        {
            continue;
        }
        switch (token)
        {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return;
            
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
}

/* checks if the first input is correct */
int readInput(char *argv[])
{
    char input[20], output[20],strategy[20];
    if(sscanf(argv[1], "%s ", input) != 1 ||
       sscanf(argv[2], "%s ", output) != 1 ||
       sscanf(argv[3], "%d", &numberThreads) != 1 ||
       sscanf(argv[4], "%s", strategy) != 1)
    {
        return 0;
    }
    /*
    if(sscanf(argv[1], "%s ", input) != 1)
    {
        return 0;
    }
    else if(sscanf(argv[2], "%s ", output) != 1)
    {
        return 0;
    }
    else if(sscanf(argv[3], "%d", &numberThreads) != 1)
    {
        return 0;
    }
    else if(sscanf(argv[4], "%s", synchstrategy) != 1)
    {
        return 0;
    } */

    if(!strcmp(strategy,"mutex"))
    {
        synchstrategy = MUTEX;
    }
    else if (!strcmp(strategy ,"rwlock"))
    {
        synchstrategy = RWLOCK;
    }
    else
    {
        synchstrategy = NOSYNC;
    }

    inputFile = fopen(input, "r");

    if (inputFile == NULL)
    {
        fprintf(stderr, "%s: No such file or directory\n", input);
        exit(EXIT_FAILURE);
    }

    outputFile = fopen(output, "w");
    return 1;
}

void *applyCommands()
{
    while(!NULL)
    {
        write_lock_func();
        if(numberCommands<=0) {
            unlock_func();
            break;
        }
        const char* command = removeCommand();
        unlock_func();
        if (command == NULL)
            continue;

        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(command, "%c %s %c", &token, name, &type);
        if (numTokens < 2)
        {
            fprintf(stderr, "Error: invalid command in Queue\n");
            exit(EXIT_FAILURE);
        }

        int searchResult;
        switch (token)
        {
            case 'c':
                switch (type)              
                {
                    case 'f':
                        printf("Create file: %s\n", name);

                        create(name, T_FILE);   
                       
                        break;
                    case 'd':
                        printf("Create directory: %s\n", name);

                        create(name, T_DIRECTORY);  

                        break;
                    default:
                        fprintf(stderr, "Error: invalid node type\n");
                        exit(EXIT_FAILURE);
                }
                break;
            case 'l': 
                
                searchResult = lookup(name);

                if (searchResult >= 0)
                    printf("Search: %s found\n", name);
                else
                    printf("Search: %s not found\n", name);
                break;

            case 'd':
                printf("Delete: %s\n", name);


                delete(name);

                break;
            default: { /* error */
                fprintf(stderr, "Error: command to apply\n");
                exit(EXIT_FAILURE);
            }
        }
    }
    return NULL;
}

void threaded_apply_comands()
{
    int i;
    pthread_t *pid;
    pid = (pthread_t*)malloc(sizeof(pthread_t)*numberThreads);

    /* two for() cycles create and join the necessary threads */
    for(i = 0; i < numberThreads; i++)
    {
        if(pthread_create(&pid[i], NULL, applyCommands, NULL) != 0)
        {
            printf("error creating thread.\n");
            exit(EXIT_FAILURE);
        }
    }
    for(i = 0; i < numberThreads; i++)     
    {
        if(pthread_join(pid[i], NULL) != 0)
        {
            printf("error joining thread.\n");
            exit(EXIT_FAILURE);
        }
    }

}

int main(int argc, char* argv[])
{
    struct timeval t1, t2;
    double elapsedTime;
    
    /* pthread_mutex_lock(&lock);
    pthread_mutex_unlock(&lock);*/ /* isto esta aqui so para fazer copy paste rapidamente !!!!!!!!*/


    gettimeofday(&t1, NULL);

    if(!readInput(argv))
    {
        fprintf(stderr, "Error: invalid command.\n");
        exit(EXIT_FAILURE);
    }
    /* Initiates the lock according with the synchstrategy */

    lock_init();    /* deviamos passar a syncstrategy como argumento */
    
    /* init filesystem */
    init_fs();
    
    /* process input and print tree */
    processInput(inputFile);

    threaded_apply_comands();

    print_tecnicofs_tree(outputFile);

    /* release allocated memory */
    destroy_fs();
    

    /* penso que seja suposto como era em python */
    fclose(inputFile);
    fclose(outputFile);

    gettimeofday(&t2, NULL);    
    elapsedTime=(t2.tv_usec - t1.tv_usec);
    elapsedTime/=1000000;    
    printf("TecnicoFS completed in %.8f seconds.\n",elapsedTime);
    
    exit(EXIT_SUCCESS);
}
